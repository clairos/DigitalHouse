module.exports = {
  host: "localhost",
  dialect: "mysql",
  username: "root",
  port: 3306,
  password: "",
  database: "dhgram",
};
